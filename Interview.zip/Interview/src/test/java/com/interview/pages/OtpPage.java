package com.interview.pages;

import framework.ContextManager;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import utils.DeviceHelper;

public class OtpPage {

    AppiumDriver driver;
    DeviceHelper deviceHelper;

    public OtpPage() {
        driver = ContextManager.getDriver();
        deviceHelper = new DeviceHelper();
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    @AndroidFindBy(xpath = "//*[@content-desc='Auto-fill code']")
    MobileElement autoFillElement;

    @AndroidFindBy(xpath = "//android.widget.EditText")
    MobileElement otpField;

    public boolean isAutoFillAppear() {
        return deviceHelper.isElementPresent(autoFillElement);
    }

    public void enterOtp(String otp) {
        deviceHelper.waitTillElementVisible(otpField);
        otpField.sendKeys(otp);
    }
}
