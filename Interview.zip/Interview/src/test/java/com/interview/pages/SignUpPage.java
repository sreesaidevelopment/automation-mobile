package com.interview.pages;

import framework.ContextManager;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileCommand;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import utils.DeviceHelper;

public class SignUpPage {
    AppiumDriver driver;
    DeviceHelper deviceHelper;

    public SignUpPage() {
        driver = ContextManager.getDriver();
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        deviceHelper = new DeviceHelper();
    }

    @AndroidFindBy(xpath = "//android.view.View[@content-desc='Create an account']")
    MobileElement createAccountTitle;

    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@text, 'Full name')]")
    MobileElement fullNameField;

    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@text, 'Email')]")
    MobileElement emailIdField;

    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@text, 'Create password')]")
    MobileElement createPasswordField;

    @AndroidFindBy(id = "com.google.android.gms:id/cancel")
    MobileElement nonOfTheAboveButton;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc='Continue']")
    MobileElement continueButton;

    public void enterNameInFullNameField(String name) {
        deviceHelper.waitTillElementVisible(fullNameField);
        fullNameField.sendKeys(name);
    }

    public void enterInEmailField(String email) {
        deviceHelper.waitAndClick(emailIdField);
        if (isNonOfTheAboveButtonAppear()) {
            clickOnNoneOfTheAboveButton();
        }
        emailIdField.sendKeys(email);
    }

    public void enterInCreatePasswordField(String password) {
        deviceHelper.waitAndClick(createPasswordField);
        createPasswordField.sendKeys(password);
    }

    public boolean isCreateAccountPageAppear() {
        return deviceHelper.isElementPresent(createAccountTitle);
    }

    public boolean isNonOfTheAboveButtonAppear() {
        return deviceHelper.isElementPresent(nonOfTheAboveButton);
    }

    public void clickOnNoneOfTheAboveButton() {
        deviceHelper.waitAndClick(nonOfTheAboveButton);
    }


    public OtpPage clickOnContinueButton() {
        deviceHelper.waitAndClick(continueButton);
        return new OtpPage();
    }

    public boolean isContinueButtonAppear() {
        return deviceHelper.isElementPresent(continueButton);
    }
}
