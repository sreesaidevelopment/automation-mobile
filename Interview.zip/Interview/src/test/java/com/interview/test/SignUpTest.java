package com.interview.test;

import com.interview.pages.OtpPage;
import com.interview.pages.SignUpPage;
import framework.TestSetUp;
import org.testng.Assert;
import org.testng.annotations.Test;
import utils.DeviceHelper;

import javax.xml.bind.helpers.DefaultValidationEventHandler;

public class SignUpTest extends TestSetUp {

    @Test(enabled = true)
    public void verifySignUpValidation() {
        DeviceHelper deviceHelper = new DeviceHelper();
        SignUpPage signUpPage = new SignUpPage();

        if (signUpPage.isNonOfTheAboveButtonAppear()) {
            signUpPage.clickOnNoneOfTheAboveButton();
        }
        signUpPage.enterNameInFullNameField(FULL_NAME);
        signUpPage.enterInEmailField(EMAIL_ID);
        signUpPage.enterInCreatePasswordField(PASSWORD);
        Assert.assertTrue(signUpPage.isContinueButtonAppear(), "Continue button should appear in create account page");
        OtpPage otpPage = signUpPage.clickOnContinueButton();
        if (otpPage.isAutoFillAppear()) {
            deviceHelper.clickBackButton();
        }
        otpPage.enterOtp("123456");
        if (otpPage.isAutoFillAppear()) {
            deviceHelper.clickBackButton();
        }

    }
}
