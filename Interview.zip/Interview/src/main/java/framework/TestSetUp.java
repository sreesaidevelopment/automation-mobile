package framework;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import java.net.MalformedURLException;

public class TestSetUp extends TestSetUpFactory{


    @BeforeSuite(alwaysRun = true)
    public void launchApp() throws MalformedURLException {
        launchCoinDcx();//We can pass xml parameters to this method as well
    }


}
