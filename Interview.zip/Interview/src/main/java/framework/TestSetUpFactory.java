package framework;

import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import utils.Constants;

import java.net.MalformedURLException;
import java.net.URL;

public class TestSetUpFactory implements Constants {

    AppiumDriver driver;

    public void launchCoinDcx() throws MalformedURLException {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("platformName", "android");
        capabilities.setCapability("automationName", "uiautomator2");
        capabilities.setCapability("appPackage", "com.coindcx.btc");
        capabilities.setCapability("appActivity", "com.coindcx.MainActivity");

        driver = new AppiumDriver(new URL("http://127.0.0.1:4724/wd/hub"), capabilities);
        ContextManager.setDriver(driver);
    }
}
