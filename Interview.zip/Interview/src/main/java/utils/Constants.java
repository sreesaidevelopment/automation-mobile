package utils;

public interface Constants {

    public String FULL_NAME = "Narayana Sreesai Ranganadh";
    public String EMAIL_ID = "ssaaii4499@gmail.com";
    public String PASSWORD = "Sai@9491";
}
