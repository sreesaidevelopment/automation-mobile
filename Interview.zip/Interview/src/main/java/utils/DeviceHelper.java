package utils;

import framework.ContextManager;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import org.omg.CORBA.TIMEOUT;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DeviceHelper {

    AppiumDriver driver;

    public DeviceHelper() {
        driver = ContextManager.getDriver();
    }

    int waitTime = 20;

    public void waitTillElementVisible(MobileElement element) {
        WebDriverWait wait = new WebDriverWait(driver, waitTime);
        wait.until(ExpectedConditions.visibilityOf(element));
    }

    public void waitTillElementVisible(MobileElement element, int waitTime) {
        WebDriverWait wait = new WebDriverWait(driver, waitTime);
        wait.until(ExpectedConditions.visibilityOf(element));
    }

    public void waitAndClick(MobileElement element) {
        waitTillElementVisible(element);
        element.click();
    }

    public boolean isElementPresent(MobileElement element) {
        try {
            waitTillElementVisible(element, 5);
            return element.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public void clickBackButton() {
        ((AppiumDriver)driver).navigate().back();
    }
}
