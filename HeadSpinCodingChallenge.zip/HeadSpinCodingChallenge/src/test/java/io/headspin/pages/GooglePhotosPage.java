package io.headspin.pages;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.headspin.caps.ContextManager;
import io.headspin.utils.DeviceHelper;
import org.openqa.selenium.support.PageFactory;

public class GooglePhotosPage {

    DeviceHelper deviceHelper() {return new DeviceHelper(ContextManager.getDriver());}

    public GooglePhotosPage() {
        PageFactory.initElements(new AppiumFieldDecorator(ContextManager.getDriver()), this);
    }

    @AndroidFindBy(xpath = "//android.view.ViewGroup[contains(@content-desc, 'Photo taken on')]")
    MobileElement image;

    @AndroidFindBy(id = "com.google.android.apps.photos:id/photos_overflow_icon")
    MobileElement optionsButton;

    @AndroidFindBy(xpath = "(//*[@resource-id='com.google.android.apps.photos:id/label'])[2]")
    MobileElement fileName;

    @AndroidFindBy(xpath = "//*[@resource-id='com.google.android.apps.photos:id/exif_item_layout']//*[@resource-id='com.google.android.apps.photos:id/label']")
    MobileElement imagePath;

    @AndroidFindBy(id = "com.google.android.apps.photos:id/video_player_controller_fragment_container")
    MobileElement imagePreview;

    @AndroidFindBy(id = "com.google.android.apps.photos:id/not_now_button")
    MobileElement doNotBackUp;

    @AndroidFindBy(id = "com.google.android.apps.photos:id/tab_library")
    MobileElement libraryTab;

    @AndroidFindBy(xpath = "//*[@content-desc='Camera, album']")
    MobileElement cameraLibrary;


    public void clickOnLibraryTab() {
        deviceHelper().waitTillElementToBeVisible(libraryTab);
        libraryTab.click();
        deviceHelper().reporting("Click on Librabry tab in google photos app");
    }

    public void clickOnCameraLibrary() {
        deviceHelper().waitTillElementToBeVisible(cameraLibrary);
        cameraLibrary.click();
        deviceHelper().reporting("Click on Camera Library from Library page");
    }

    /**
     * This method is to click on first image in google photos app
     */
    public void clickOnFirstImage() {
        deviceHelper().waitTillElementToBeVisible(image);
        image.click();
        deviceHelper().reporting("Click on first image in google photos page");
    }

    /**
     * This method is to click on options button for image preview screen
     */
    public void clickOnImageOptions() {
        deviceHelper().waitTillElementToBeVisible(optionsButton);
        optionsButton.click();
        deviceHelper().reporting("Click on Image Options button in image preview screen");
    }

    /**
     * This method is to get image path in image details
     */
    public String getImagePath() {
        deviceHelper().waitTillElementToBeVisible(imagePath);
        return imagePath.getText();
    }

    public void clickOnDoNotBackUpButton() {
        if (deviceHelper().isElementPresent(doNotBackUp)) {
            doNotBackUp.click();
            deviceHelper().reporting("Click on Do Not Backup button");
        }
    }
}
