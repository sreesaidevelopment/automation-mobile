package io.headspin.pages;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.headspin.caps.ContextManager;
import io.headspin.utils.DeviceHelper;
import org.apache.xalan.transformer.XalanProperties;
import org.openqa.selenium.support.PageFactory;

public class GmailComposePage {

    DeviceHelper deviceHelper() {return new DeviceHelper(ContextManager.getDriver());}

    public GmailComposePage() {
        PageFactory.initElements(new AppiumFieldDecorator(ContextManager.getDriver()), this);
    }

    @AndroidFindBy(id = "com.google.android.gm:id/compose_button")
    MobileElement composeButton;

    @AndroidFindBy(xpath = "//android.view.ViewGroup[@resource-id='com.google.android.gm:id/peoplekit_autocomplete_chip_group']//android.widget.EditText")
    MobileElement toField;

    @AndroidFindBy(id = "com.google.android.gm:id/subject")
    MobileElement subjectField;

    @AndroidFindBy(id = "com.google.android.gm:id/add_attachment")
    MobileElement addAttachmentButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.google.android.gm:id/title' and @text='Attach file']")
    MobileElement attachFileLink;

    @AndroidFindBy(id = "com.google.android.documentsui:id/action_menu_select")
    MobileElement selectButton;

    @AndroidFindBy(id = "com.google.android.gm:id/attachment_tile_title")
    MobileElement attachedFileTitle;

    @AndroidFindBy(id = "com.google.android.gm:id/send")
    MobileElement sendButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.google.android.gm:id/description_text' and @text='Sent']")
    MobileElement sentMessage;

    public void clickOnComposeButton() {
        deviceHelper().waitTillElementToBeVisible(composeButton);
        composeButton.click();
        deviceHelper().reporting("Click on Compose button");
    }

    public void enterToMailId(String mailId) {
        deviceHelper().waitTillElementToBeVisible(toField);
        toField.sendKeys(mailId);
        deviceHelper().reporting("Enter "+mailId+" in TO field");
    }

    public void enterSubjectToMail(String text) {
        deviceHelper().waitTillElementToBeVisible(subjectField);
        subjectField.sendKeys(text);
        deviceHelper().reporting("Enter subject to the mail: "+text);
    }

    public void clickOnAttachmentIcon() {
        deviceHelper().waitTillElementToBeVisible(addAttachmentButton);
        addAttachmentButton.click();
        deviceHelper().reporting("Click on Add Attachment button");
    }

    public void clickOnAttachLink() throws InterruptedException {
        deviceHelper().waitTillElementToBeVisible(attachFileLink);
        attachFileLink.click();
        deviceHelper().reporting("Click on Attach Link in compose mail");
        Thread.sleep(3000);
    }

    public void clickOnSelectButton() {
        deviceHelper().waitTillElementToBeVisible(selectButton);
        selectButton.click();
        deviceHelper().reporting("Click on Select button in compose mail");
    }

    public String getAttachedFileName() {
        deviceHelper().waitTillElementToBeVisible(attachedFileTitle);
        return attachedFileTitle.getText();
    }

    public void clickOnSendButton() {
        deviceHelper().waitTillElementToBeVisible(sendButton);
        sendButton.click();
        deviceHelper().reporting("Click on send button in compose mail");
    }

    public boolean isSentMessageAppearing() {
        try {
            deviceHelper().waitTillElementToBeVisible(sentMessage);
            return sentMessage.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

}
