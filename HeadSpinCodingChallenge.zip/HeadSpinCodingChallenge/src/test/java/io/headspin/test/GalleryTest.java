package io.headspin.test;

import io.headspin.caps.ContextManager;
import io.headspin.config.TestSetup;
import io.headspin.pages.GmailComposePage;
import io.headspin.pages.GooglePhotosPage;
import io.headspin.utils.DeviceHelper;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;

public class GalleryTest extends TestSetup {

    DeviceHelper deviceHelper() {return new DeviceHelper(ContextManager.getDriver());}

    @Test(enabled = true, priority = 1, description = "Verify File functionality in Google Photos and Gmail applications")
    public void verifyFileFunctionalityInGoogleAndGmail() throws IOException, InterruptedException {
        String googlePhotosPackage = "com.google.android.apps.photos";
        String gmailPackage = "com.google.android.gm";
        deviceHelper().launchApp(googlePhotosPackage);
        GooglePhotosPage googlePhotosPage = new GooglePhotosPage();
        googlePhotosPage.clickOnDoNotBackUpButton();
        String filePath = System.getProperty("user.dir") + "/src/TestImage.png";
        String fileLocationInMobile = "/storage/emulated/0/DCIM/TestImage.png";
        deviceHelper().sendFileToDevice(filePath, fileLocationInMobile);
        deviceHelper().killApp(googlePhotosPackage);
        deviceHelper().launchApp(googlePhotosPackage);
        googlePhotosPage.clickOnLibraryTab();
        googlePhotosPage.clickOnCameraLibrary();
        googlePhotosPage.clickOnFirstImage();
        googlePhotosPage.clickOnImageOptions();
        Assert.assertEquals(googlePhotosPage.getImagePath(), fileLocationInMobile, "Image path should match with expected path");
        //Gmail Functionality
        deviceHelper().launchApp(gmailPackage);
        GmailComposePage gmailComposePage = new GmailComposePage();
        gmailComposePage.clickOnComposeButton();
        gmailComposePage.enterSubjectToMail("Test Mail");
        gmailComposePage.enterToMailId("sreesai.ranganadh@gmail.com");
        gmailComposePage.clickOnAttachmentIcon();
        gmailComposePage. clickOnAttachLink();
        String[] pathBreak = fileLocationInMobile.split("/");
        String fileName = pathBreak[pathBreak.length-1];
        deviceHelper().generateTextAndReturnElement(fileName).click();
//        gmailComposePage.clickOnSelectButton();
        Assert.assertEquals(gmailComposePage.getAttachedFileName(), fileName, "Filename should match with attached file name");
        gmailComposePage.clickOnSendButton();
        Assert.assertTrue(gmailComposePage.isSentMessageAppearing(), "Sent message should appear post sending");
    }
}
