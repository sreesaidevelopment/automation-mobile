package io.headspin.config;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import groovy.transform.Synchronized;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.Setting;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import io.headspin.caps.ContextManager;
import io.headspin.reporting.ExtentTestFactory;
import io.headspin.reporting.ExtentTestFactoryParent;
import io.headspin.reporting.RetryAnalyzer;
import io.headspin.utils.DeviceHelper;
import io.qameta.allure.Attachment;
import io.restassured.response.Response;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Test;

import java.io.*;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.*;
import java.util.concurrent.TimeUnit;

import static com.google.common.collect.ObjectArrays.concat;


public class TestSetupFactory extends RetryAnalyzer {
    public static ExtentTestFactory extentTestFactory;
    public ConfigurationManager prop;
    public AppiumDriverLocalService service;
    public AppiumServiceBuilder builder;
    public AppiumDriver<MobileElement> driver;
    private static ExtentReports extent;
    public static String filePath = System.getProperty("user.dir") + "/Reports/" + extentTestFactory.getPath();
    public static String strProjectPath = System.getProperty("user.dir");
    public Set<String> processID;
    private static final String[] OS_LINUX_RUNTIME = {"/bin/bash", "-l", "-c"};
    private static final String[] WIN_RUNTIME = { "cmd.exe", "/C" };
    DeviceHelper deviceHelper;


    /**
     * Constructor to load configSC.properties
     */
    public TestSetupFactory() {
        try {
            if(prop == null) {
                prop = new ConfigurationManager().getInstance("config.properties");
            }
            this.driver = ContextManager.getDriver();
            deviceHelper = new DeviceHelper(driver);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Load Extent Config xml file
     */
    public void loadExtentFile(String Devices, String firstPort, String buildName) {
        System.out.print("***Devices2****=="+Devices);
        System.out.print("***firstPort2****=="+firstPort);
        new File(filePath);
        extent = new ExtentReports();
        extent.attachReporter(getHtmlReporter());
        extent.setSystemInfo("Build", buildName);
        extent.setSystemInfo("Author", "QA Team");
    }

    /**
     * Start Appium Server
     */
    public void startAppiumServer(String Devices, String firstPort) {
        if(Devices == null )
            Devices = "1";
        if(firstPort == null)
            firstPort = prop.getProperty("endpoint").split(":")[1];
        String ipAddress = "0.0.0.0";
        if (prop.getProperty("Runner").equalsIgnoreCase("local")) {
            System.out.print("Devices******=="+Devices + "***firstPort****=="+firstPort);
            int devices = Integer.parseInt(Devices);
            int port = Integer.parseInt(firstPort);
            processID = new HashSet<>();
//            Map<String,String> envVariables = new HashMap<>();
//            envVariables.put("ANDROID_HOME",prop.getProperty("android_home"));
            try {
                for (int i = 0; i < devices; i++) {
                    builder = new AppiumServiceBuilder();
                    builder.withIPAddress(ipAddress);
                    builder.usingPort(port + i);
//                    builder.withAppiumJS(new File(prop.getProperty("appiumMain")));
//                    builder.withEnvironment(envVariables);
                    service = builder.build();
//                    service = AppiumDriverLocalService.buildDefaultService();
                    service.start();
                    service.clearOutPutStreams();
                    deviceHelper.waitInSec(1);
                    String[] cmd = { "/bin/sh", "-c", "ps -A | grep appium" };
                    Process p = Runtime.getRuntime().exec(cmd);
                    BufferedReader stdInput = new BufferedReader(new
                            InputStreamReader(p.getInputStream()));
                    BufferedReader stdError = new BufferedReader(new
                            InputStreamReader(p.getErrorStream()));
                    System.out.println("Here is the standard output of the command:\n");
                    String s;
                    String pid[];
                    while ((s = stdInput.readLine()) != null) {
                        System.out.println(s);
                        if (s.contains("--address 0.0.0.0")) {
                            pid = s.split("\\?\\?");
                            processID.add(pid[0]);
                        }
                    }
                    stdInput.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Stop Appium Server
     * ps -A | grep appium
     * pkill -9 -f appium
     */
    public void stopAppiumServer(String Devices) {
        if (prop.getProperty("Runner").equalsIgnoreCase("local") || prop.getProperty("stf").equalsIgnoreCase("true")) {
            try {
                for (String pId: processID) {
                    try {
                        Process p = Runtime.getRuntime().exec("kill " + pId);

                    } catch (Exception e) {
                        ProcessBuilder processBuilder = new ProcessBuilder("kill " + pId);
                        processBuilder.start();
                    }
                    deviceHelper.waitInSec(5);
                }
                service.stop();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            try {
                service.stop();
            }
            catch (Exception e ){

            }
        }

    }


    public void configExtenTest(String className) {

        ExtentTest parent = extent.createTest(className);
        ExtentTestFactoryParent.setExtentTest(parent);
        ExtentTestFactory.setExtentTest(parent);
    }


    public void startTest(Method name) {
        ExtentTest child;
        child = ExtentTestFactoryParent.getExtentTest()
                .createNode(name.getName());
        ExtentTestFactory.setExtentTest(child);
        Test test = name.getAnnotation(Test.class);
        ExtentTestFactory.getExtentTest().info(test.description()); // description of test in first line of test
    }

    /**
     * Launch App
     */
    public void launchApplication() {
        DesiredCapabilities capabilities;
        capabilities = configCapabilities();

        try {
            driver = new AndroidDriver<MobileElement>(getUrl(), capabilities);
        }
        catch (SessionNotCreatedException e){
            e.printStackTrace(); // try again
            driver = new AndroidDriver<MobileElement>(getUrl(), capabilities);
        }
        driver.setSetting(Setting.WAIT_FOR_IDLE_TIMEOUT, 0);
        driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        ContextManager.setDriver(driver);
    }

    /***
     * Description : creates url from string object from endpoint
     */
    public URL getUrl(){
        URL url = null;
        try {
            url = new URL(getEndPoint());
        }
        catch( Exception e) {}
        return url;
    }

    /**
     * this method creates endpoint based on port, if required basedo nif else statements
     * if needed we will add cloud details in this function only
     */
    public String getEndPoint() {
        return "http://" + prop.getProperty("endpoint") + "/wd/hub";
    }


    /**
     * common capabilities for appium and device which will be common for all cases
     * @return
     */
    public DesiredCapabilities configCapabilities(){
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("newCommandTimeout", prop.getProperty("newCommandTimeout"));
        capabilities.setCapability("platformName", prop.getProperty("platformName"));
        capabilities.setCapability("deviceName", prop.getProperty("deviceName"));
        capabilities.setCapability(MobileCapabilityType.UDID, prop.getProperty("deviceName"));
        capabilities.setCapability("appPackage", prop.getProperty("appPackage"));
        capabilities.setCapability("appActivity", prop.getProperty("appActivity"));
        capabilities.setCapability(MobileCapabilityType.ORIENTATION, "PORTRAIT");
        capabilities.setCapability("automationName", prop.getProperty("automationName"));
        capabilities.setCapability("uiautomator2ServerLaunchTimeout", "80000");
        capabilities.setCapability("adbExecTimeout", "80000");
        capabilities.setCapability("app",  prop.getProperty("app"));
        capabilities.setCapability(AndroidMobileCapabilityType.AUTO_GRANT_PERMISSIONS, true);
        capabilities.setCapability("systemPort", prop.getProperty("systemPort"));
//        capabilities.setCapability("noReset", true);
        return capabilities;
    }


    /**
     * Quiting the Driver
     */
    public void closeApplication() {
        if (ContextManager.getDriver() != null) {
            ContextManager.getDriver().quit();
        }
    }

    /**
     * Flush the report and Stop Appium server
     */
    public void flushReport(@Optional String Devices) throws Exception {
        extent.flush();
        System.out.println("Extent Reports is available here =>> " + filePath);
        System.out.println("After Suite Executed");
        if (prop.getProperty("Runner").equalsIgnoreCase("Local")) {
            stopAppiumServer(Devices);
        }
    }

    /**
     * @return ExtentHtmlReporter Instance
     */
    private static ExtentSparkReporter getHtmlReporter() {
        ExtentSparkReporter htmlReporter = new ExtentSparkReporter(filePath);
        htmlReporter.config().setDocumentTitle("Headspin-Automation");
        htmlReporter.config().setReportName("Mobile Automation");
        htmlReporter.config().setTheme(Theme.DARK);
        return htmlReporter;
    }

    /**
     * Result Status Capture
     *
     * @param result
     */
    public void testResultCapture(Method method, ITestResult result)  {

        System.out.println("===============================Check status======================================" + result.getStatus());
        /**
         * Success Block
         */
        if (result.getStatus() == ITestResult.SUCCESS) {
            ExtentTestFactory.getExtentTest().log(Status.PASS, result.getMethod().getMethodName() + " Passed");
        }
        /**
         * Failure Block
         */
        try {

            if (result.getStatus() == ITestResult.FAILURE) {
                if (result.getThrowable().getMessage().contains("Skipped By retry")) {
                    ExtentTestFactory.getExtentTest().getExtent().removeTest(ExtentTestFactory.getExtentTest());
                } else {
                    StringWriter exceptionInfo = new StringWriter();
                    result.getThrowable().printStackTrace(new PrintWriter(exceptionInfo));

                    String methodClassName = result.getThrowable().getMessage();
                    for (StackTraceElement stack : result.getThrowable().getStackTrace()) {
                        if (stack.getClassName().contains("io.headspin.pages")) {
                            methodClassName = methodClassName + "   Failed in Class: " + stack.getClassName() +
                                    ",  in Method : " + stack.getMethodName() +
                                    ",  and Line : " + stack.getLineNumber();
                            break;
                        }
                    }

                    ExtentTestFactory.getExtentTest().fail(methodClassName);
                    ExtentTestFactory.getExtentTest().addScreenCaptureFromBase64String(takeScreenShot());
                }
            }
        }catch (Exception e){
            e.printStackTrace();
            ExtentTestFactory.getExtentTest().fail("Exception occured " + e.getMessage());
            result.setStatus(2); // mark tst as failed
        }

    }

    protected String takeScreenShot() {
        try {
            File snapshotTmpFile = ContextManager.getDriver().getScreenshotAs(OutputType.FILE);
            File snapshotFile = new File(System.getProperty("user.dir") + "/Reports/", snapshotTmpFile.getName());
            FileUtils.moveFile(snapshotTmpFile, snapshotFile);
            String encodeImage = convertImageToBase64(snapshotFile);
            snapshotFile.delete();
            return encodeImage;
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Convert Image to Base64
     *
     * @param file
     * @return
     * @throws IOException
     */
    private String convertImageToBase64(File file) throws IOException {
        byte[] fileContent = FileUtils.readFileToByteArray(file);
        String encodedString = Base64.getEncoder().encodeToString(fileContent);
        return "data:image/jpg;base64, " + encodedString;
    }

    /**
     * Flush the report
     */
    @Synchronized
    public void flushImmediateReport() {
        extent.flush();
    }

}

