package io.headspin.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ConfigurationManager {

    private ConfigurationManager instance = null;
    private Properties prop = new Properties();

    public ConfigurationManager(String configFile) throws IOException {
        FileInputStream inputStream = new FileInputStream(configFile);
        prop.load(inputStream);
    }
    public ConfigurationManager() throws IOException {
    }

    public String getProperty(String key) {
        return prop.getProperty(key);
    }

    public ConfigurationManager getInstance(String fileName) throws IOException {
        if (this.instance == null) {
            String configFile = System.getProperty("user.dir")+"/src/main/java/io/headspin/config"+ File.separator+fileName;
            this.instance = new ConfigurationManager(configFile);
        }
        return this.instance;
    }
    private static String getPropertyFilePath() {

        String propFilePath = "";
        String currentDir = System.getProperty("user.dir");

        File file = new File(currentDir);
        String capsPath = file.getParentFile().getPath() + File.separator + "caps";
        File capsDir = new File(capsPath);

        if (capsDir.exists()) {
            propFilePath = capsDir.getPath();
            System.out.println("pCLoudy");
        } else {
            propFilePath = currentDir + File.separator + "caps";
        }

        return propFilePath;

    }
    private static String getResourcesPath() {

        String propFilePath = "";
        String currentDir = System.getProperty("user.dir");

        File file = new File(currentDir);
        String capsPath = file.getParentFile().getPath() + File.separator + "caps";
        File capsDir = new File(capsPath);

        if (capsDir.exists()) {
            propFilePath = capsDir.getPath();
            System.out.println("pCLoudy");
        } else {
            propFilePath = currentDir + File.separator + "caps";
        }

        return propFilePath;

    }

}
