package io.headspin.config;

import io.headspin.caps.ContextManager;
import io.headspin.caps.WebDriverListener;
import io.headspin.reporting.ExtentTestFactory;
import io.headspin.utils.DeviceHelper;
import io.headspin.utils.GenericUtils;
import lombok.Synchronized;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;

import java.io.IOException;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Listeners({WebDriverListener.class})
public class TestSetup extends TestSetupFactory {
    public static String testResults = "Scenario,Status,StartTime,EndTime,TimeInSeconds,ClassName,PODName\n";
    public static String buildName = "";
    public GenericUtils genericUtils = new GenericUtils();
    public  Map<String, String> allParameters = new LinkedHashMap<String, String>();
    public static String suiteName = "";

    @Parameters({"Devices", "FirstPort"})
    @BeforeSuite(alwaysRun = true)
    public void beforeSuite(@Optional String Devices, @Optional String FirstPort,ITestContext testContext) throws Exception {
        allParameters=testContext.getCurrentXmlTest().getAllParameters();
        suiteName = testContext.getCurrentXmlTest().getSuite().getName();
        List<String> abc = testContext.getCurrentXmlTest().getIncludedGroups();
        loadExtentFile(Devices, FirstPort,buildName);
        startAppiumServer(Devices, FirstPort);
    }

    @BeforeTest(alwaysRun = true)
    public void beforeTest() {
        System.out.println("=============================BeforeTest in TestSetup is Executed==============================");
    }

    @Parameters({"PlatformVersion", "DeviceName", "Port", "SystemPort", "DeviceId", "HeadSpinDeviceName", "HeadSpinDeviceID", "HeadSpinDeviceURL"})
    @BeforeClass(alwaysRun = true)
    public void beforeClass(@Optional String PlatformVersion, @Optional String DeviceName, @Optional String Port, @Optional String SystemPort, @Optional String DeviceId,
                            @Optional String HeadSpinDeviceName, @Optional String HeadSpinDeviceID, @Optional String HeadSpinDeviceURL) throws IOException {
        System.out.println("=============================BeforeClass in TestSetup is executing==============================");
        configExtenTest(getClass().getName().substring(getClass().getName().lastIndexOf('.') + 1));
        launchApplication();
        System.out.println("Before class in Test Setup is executed");
    }


    @BeforeMethod(alwaysRun = true) //Initiate this if you have to launch the appium once for all set of tests
    public void beforeMethod(Method name) throws IOException, InterruptedException {
        System.out.println("==================================Before Method TestSetup=======================");
        startTest(name); // start extent test
        String[] classPODName = ExtentTestFactory.assignCategoryToTest(getClass().getName()); // assigning category to test - pod and test class name
        ContextManager.setClassPODName(classPODName);
    }


    @AfterMethod(alwaysRun = true) //Initiate those if you have to launch the appium once for all set of tests
    public void afterMethod(Method method, ITestResult result) throws NullPointerException {
        System.out.println("==================================After Method TestSetup=======================");
        testResultCapture(method, result);
    }


    public String markTestBasedOnStatus(ITestResult result) {
        String testResult = "";
        if (result.getStatus() == ITestResult.FAILURE) {
            testResult = "Fail";
        } else if (result.getStatus() == ITestResult.SUCCESS) {
            testResult = "Pass";
        } else  { // means passed{
            testResult = "Skip";
        }
        return testResult;
    }

    @AfterClass(alwaysRun = true)
    public void afterClass() {
        System.out.println("==================================After Class TestSetup=======================");
        closeApplication();
    }

    @AfterMethod(alwaysRun = true)
    public void afterMethod2() {
        System.out.println("After method flushing report");
        flushImmediateReport();
    }

    @Parameters({"Devices"})
    @AfterSuite(alwaysRun = true)
    public void afterSuite(@Optional String Devices) throws Exception {
        System.out.println("After Suite");
        flushReport(Devices);
    }

}
