package io.headspin.utils;

import com.aventstack.extentreports.ExtentTest;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AndroidBy;
import io.headspin.caps.ContextManager;
import io.headspin.reporting.ExtentTestFactory;
import org.apache.xpath.operations.And;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.net.ContentHandler;

public class DeviceHelper {

    AppiumDriver driver;
    public DeviceHelper(AppiumDriver driver) {
        if (driver != null) {
            this.driver = driver;
        } else {
            this.driver = ContextManager.getDriver();
        }
    }

    public void waitInSec(int sec) {
        try {
            driver.wait(sec);
        } catch (Exception e) {}
    }

    public void sendFileToDevice(String filePath, String devicePath) throws IOException {
        ((AndroidDriver)driver).pushFile(devicePath, new File(filePath));
    }

    public void killApp(String appPackage) {
        ((AndroidDriver)driver).terminateApp(appPackage);
    }

    public void launchApp(String appPackage) {
        ((AndroidDriver)driver).activateApp(appPackage);
        try {
            Thread.sleep(3000);
        } catch (Exception e){}
    }

    public void waitTillElementToBeVisible(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.visibilityOf(element));
    }

    public void reporting(String message) {
        ExtentTest loggerReport = ExtentTestFactory.getExtentTest();
        loggerReport.info(message);
        System.out.println("INFO- "+message);
    }

    public void tapAndroidBack() {
        ((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.BACK));
        reporting("Click default back button on android device");
    }

    public MobileElement generateTextAndReturnElement(String text) {
        try {
            MobileElement element = (MobileElement) driver.findElement(By.xpath("//*[contains(@text, '"+text+"')]"));
            waitTillElementToBeVisible(element);
            reporting("Get element with text: "+text);
            return element;
        } catch (Exception e) {
            return null;
        }
    }

    public boolean isElementPresent(MobileElement element) {
        try {
            waitTillElementToBeVisible(element);
            return element.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

}
