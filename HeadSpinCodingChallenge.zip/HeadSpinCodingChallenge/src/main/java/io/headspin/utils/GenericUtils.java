package io.headspin.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.Calendar;
import java.util.Date;

/**
 * Description : this class will have generic functions, nothingto do with driver or app or devices
 */
public class GenericUtils {


    public void waitInSec(int secs) {
        System.out.println("waiting/sleeping for seconds - "+ secs);
        try {
            Thread.sleep(secs * 1000);
        } catch (InterruptedException e) {}
    }

    public int generateRandomNum(int min, int max) {
        return (int) (Math.random()*(max-min+1)+min);
    }

    public long getEpocTime(String newTime, String pattern){
    //    SimpleDateFormat crunchifyFormat = new SimpleDateFormat("MMM dd yyyy - HH:mm:aa");
    //    SimpleDateFormat crunchifyFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat crunchifyFormat = new SimpleDateFormat(pattern);
        long epochTime=0;
        try {
            Date date = crunchifyFormat.parse(newTime);
            epochTime = date.getTime();
            System.out.println("Current Time in Epoch: " + epochTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return epochTime;
    }


    public String newTime(int timeGapSecs) {
        try {
            Date today = Calendar.getInstance().getTime();
            SimpleDateFormat crunchifyFormat = new SimpleDateFormat("MMM dd yyyy - HH:mm:aa");
            String formatedTime = crunchifyFormat.format(today);
            Date d = crunchifyFormat.parse(formatedTime);
            Calendar cal = Calendar.getInstance();
            cal.setTime(d);
            cal.add(Calendar.SECOND, timeGapSecs);
            String newTime = crunchifyFormat.format(cal.getTime());
            return newTime;
        }
        catch (Exception e) { return "";}
    }


    public String getLastMonday() {
        LocalDate dt = LocalDate.now();
        return  dt.with(TemporalAdjusters.previous(DayOfWeek.MONDAY)).toString();
    }

    public String getToday() {
        LocalDate dt = LocalDate.now();
        return  dt.toString();
    }


    public String getCurrentDateInString() {
        LocalDateTime dt = LocalDateTime.now();
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd_MM_YY_HH_mm");
        String formatDateTime = dt.format(format);
        return formatDateTime;
    }

    public String dateAndTime() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy_HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        System.out.println(dtf.format(now));
        return dtf.format(now);
    }

    /**
     * Description : this functions gives Today Date in _ format
     *
     */
    public String getCurrentDateInString(String dateFormat) {
        LocalDateTime dt = LocalDateTime.now();
        DateTimeFormatter format = DateTimeFormatter.ofPattern(dateFormat);
        String formatDateTime = dt.format(format);
        return formatDateTime;
    }

    public String getTestName_Recording(String testfullName){
        String[] nameAray = testfullName.split("_");
        String name = nameAray[0];
        try {
            name += "_" + nameAray[1]; // just in case there is no _ in test case
        }
        catch(Exception e){}
        if(name.length() > 10)
            name = name.substring(0,8);
        String timedate = String.valueOf(LocalDate.now());
        timedate.replaceAll("-","_");
        timedate.replaceAll("/","_");
        name += "_" + timedate;
        return name;
    }
}
