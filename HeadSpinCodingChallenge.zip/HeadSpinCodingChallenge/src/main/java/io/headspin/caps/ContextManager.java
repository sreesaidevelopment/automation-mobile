package io.headspin.caps;

import io.appium.java_client.AppiumDriver;

public class ContextManager {

    private static ThreadLocal<AppiumDriver> driver = new ThreadLocal<>();

    public static void setDriver(AppiumDriver driver1) {
        driver.set(driver1);
    }

    public static AppiumDriver getDriver() {
        return driver.get();
    }

    private static ThreadLocal<String[]> classPODName = new ThreadLocal<String[]>();
    public static String[] getClassPODName() {
        return classPODName.get();
    }

    public static void setClassPODName(String[] value) {
        classPODName.set(value);
    }
}
